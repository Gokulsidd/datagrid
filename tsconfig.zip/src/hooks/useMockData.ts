import { useEffect, useState } from "react";

// Match the log structure from the screenshot
export type LogEntry = {
  id: number;
  date: string;
  thread: number;
  level: "DEBUG" | "INFO" | "ERROR";
  logger: string;
  exception: string;
  username: string;
  message: string;
  pageUrl: string;
};

function useMockData() {
  const [data, setData] = useState<LogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/mockData.json");
        const result = await response.json();
        setData(result as LogEntry[]);
      } catch (err) {
        setError("Failed to fetch data");
      }
    };

    fetchData();
  }, []);

  return { data, error };
}

export default useMockData;
