"use client";
import { PanelLeftOpen, Search } from "lucide-react";
import { useState } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

interface HeaderProps {
  sidebarFixed: boolean;
  setSidebarFixed: Function;
  hovering: boolean;
  setHovering: Function;
}

const Header = ({
  sidebarFixed,
  setSidebarFixed,
  hovering,
  setHovering,
}: HeaderProps) => {
  return (
    <div className="h-14 w-full border-b border-gray-200 flex justify-between gap-4 items-center px-3 pr-6 transition-all duration-500">
      <div
        onMouseEnter={() => !sidebarFixed && setHovering(true)}
      >
        <button
          onClick={() => {
            setSidebarFixed(!sidebarFixed);
            setHovering(false);
          }}
          className="bg-white p-2 rounded-md border border-gray-200 cursor-pointer"
        >
          <PanelLeftOpen className="w-5 h-5 text-accent-foreground" />
        </button>
      </div>
      <div className="flex items-center">
        <div className="flex mx-4 gap-1">
          <div className="relative w-[400px]">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
              <Search className="w-4 h-4" />
            </span>
            <Input placeholder="Search" className="pl-10 w-full" />
          </div>
          <Button variant={"primary"} size={"default"}>
            + New
          </Button>
        </div>
        <Avatar>
          <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
          <AvatarFallback>CN</AvatarFallback>
        </Avatar>
      </div>
    </div>
  );
};

export default Header;
