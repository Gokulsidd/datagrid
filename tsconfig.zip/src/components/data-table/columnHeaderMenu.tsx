"use client";

import {
  Popover,
  PopoverTrigger,
  PopoverContent,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import {
  CircleArrowDown,
  FilterIcon,
  MoreVertical,
  SortAscIcon,
  SortDescIcon,
} from "lucide-react";
import { useState } from "react";
import { ColumnFilterPopover } from "./columnFilterPopover";

interface ColumnMenuProps {
  sortDirection: "asc" | "desc" | null;
  onSortChange: (dir: "asc" | "desc" | null) => void;
  filterValues: string[];
  onFilterChange: (vals: string[]) => void;
  columnType?: "string" | "enum" | "date"; // for future extension
}

export default function ColumnHeaderMenu({
  sortDirection,
  onSortChange,
  filterValues,
  onFilterChange,
  columnType = "string",
}: ColumnMenuProps) {
  const [filterOpen, setFilterOpen] = useState(false);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button size="icon" variant="ghost" className="ml-1">
          <MoreVertical className="w-4 h-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent
        side="bottom"
        className="flex flex-col w-63 p-2 space-y-1"
      >
        <Button
          variant="ghost"
          onClick={() => onSortChange("asc")}
          className="font-normal w-full flex justify-start items-center gap-2"
        >
          <SortAscIcon className="w-4 h-4" />
          Sort Ascending
        </Button>
        <Button
          variant="ghost"
          onClick={() => onSortChange("desc")}
          className="font-normal w-full flex justify-start items-center gap-2"
        >
          <SortDescIcon className="w-4 h-4" />
          Sort Descending
        </Button>
        <Button
          variant="ghost"
          onClick={() => onSortChange(null)}
          className="font-normal w-full flex justify-start items-center gap-2"
        >
          <CircleArrowDown className="w-4 h-4" />
          Clear Sorting
        </Button>
        <Button
          variant="ghost"
          className="font-normal w-full flex justify-start items-center gap-2"
          onClick={() => setFilterOpen(!filterOpen)}
        >
          <FilterIcon className="w-4 h-4" />
          Filter Column
        </Button>
        {filterOpen && (
          <div className="p-1 border rounded-lg ">
            <ColumnFilterPopover
              initialValues={filterValues}
              onApplyAction={(vals) => {
                onFilterChange(vals);
                setFilterOpen(false);
              }}
            />
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
