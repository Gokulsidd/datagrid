"use client";

import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

export function ColumnFilterPopover({
  initialValues = [],
  onApplyAction,
}: {
  initialValues?: string[];
  onApplyAction: (vals: string[]) => void;
}) {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string[]>(initialValues);

  const filtered = useMemo(
    () =>
      initialValues.filter((v) =>
        v.toLowerCase().includes(search.toLowerCase())
      ),
    [search, initialValues]
  );

  const toggleValue = (val: string) => {
    setSelected((prev) =>
      prev.includes(val) ? prev.filter((v) => v !== val) : [...prev, val]
    );
  };

  return (
    <div className="space-y-3 w-56">
      <Input
        placeholder="Search..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="max-h-40 overflow-y-auto space-y-1">
        {filtered.map((val) => (
          <div
            key={val}
            className="flex items-center gap-2 px-1 py-1 hover:bg-accent rounded"
          >
            <Checkbox
              id={val}
              checked={selected.includes(val)}
              onCheckedChange={() => toggleValue(val)}
            />
            <label htmlFor={val} className="text-sm">
              {val}
            </label>
          </div>
        ))}
      </div>

      <Button
        size="sm"
        onClick={() => onApplyAction(selected)}
        disabled={!selected.length}
        className="w-full"
      >
        Apply Filter
      </Button>
    </div>
  );
}
