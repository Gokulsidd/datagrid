import useMockData, { LogEntry } from "@/hooks/useMockData";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import ColumnHeaderMenu from "./columnHeaderMenu";

const DataTable = () => {
  const { data, error } = useMockData();
  const columnFilters = [
    {
      key: "id",
      label: "ID",
      type: "string",
    },
    {
      key: "date",
      label: "Date",
      type: "date",
    },
    {
      key: "level",
      label: "Level",
      type: "enum",
    },
    {
      key: "logger",
      label: "Logger",
      type: "string",
    },
    {
      key: "message",
      label: "Message",
      type: "string",
    },
    {
      key: "pageUrl",
      label: "PageURL",
      type: "string",
    },
    {
      key: "thread",
      label: "Thread",
      type: "string",
    },
    {
      key: "userName",
      label: "UserName",
      type: "string",
    },
  ];

  return (
    <div className="p-4">
      <Table>
        <TableHeader>
          <TableRow>
            {columnFilters.map((col) => (
              <TableHead key={col.key}>
                <div className="flex items-center justify-between gap-2 group">
                  <p>{col.label}</p>
                  <div className="invisible group-hover:visible transition-opacity duration-200">
                    <ColumnHeaderMenu
                        sortDirection={"asc"}
                        onSortChange={(dir) => {}}
                        filterValues={[
                            ...new Set(data.map((item) => item[col.key as keyof LogEntry]?.toString() || ""))
                        ]}
                        onFilterChange={(vals) => {}}
                        />
                  </div>
                </div>
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((item) => {
            return (
              <TableRow key={item.id}>
                <TableCell>{item.id}</TableCell>
                <TableCell>{item.date}</TableCell>
                <TableCell>{item.level}</TableCell>
                <TableCell>{item.logger}</TableCell>
                <TableCell>{item.message}</TableCell>
                <TableCell>{item.pageUrl}</TableCell>
                <TableCell>{item.thread}</TableCell>
                <TableCell>{item.username}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};

export default DataTable;
