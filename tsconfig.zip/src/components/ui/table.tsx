"use client"

import * as React from "react"
import { cn } from "@/lib/utils"
import { useHeaderStore } from "@/store/useHeaderStore"

function Table({ className, ...props }: React.ComponentProps<"table">) {
  const { isHeaderVisible } = useHeaderStore()
  return (
    <div className={`relative w-full ${isHeaderVisible ? 'h-[580px]' : 'h-[645px]'}  overflow-auto rounded-md border border-neutral-300 bg-white`}>
      <table className={cn("w-full text-sm text-left", className)} {...props} />
    </div>
  )
}

function TableHeader({ className, ...props }: React.ComponentProps<"thead">) {
  return (
    <thead
      className={cn(
        "sticky top-0 z-10 bg-neutral-100 shadow-xs",
        className
      )}
      {...props}
    />
  )
}

function TableBody({ className, ...props }: React.ComponentProps<"tbody">) {
  return (
    <tbody
      className={cn("[&_tr:last-child]:border-b", className)}
      {...props}
    />
  )
}

function TableFooter({ className, ...props }: React.ComponentProps<"tfoot">) {
  return (
    <tfoot
      className={cn("bg-muted/50 border-t font-medium", className)}
      {...props}
    />
  )
}

function TableRow({ className, ...props }: React.ComponentProps<"tr">) {
  return (
    <tr
      className={cn(
        "border-b hover:bg-muted/40 transition-colors",
        className
      )}
      {...props}
    />
  )
}

function TableHead({ className, ...props }: React.ComponentProps<"th">) {
  return (
    <th 
      className={cn(
        "h-10 px-3 py-2 whitespace-nowrap font-medium text-muted-foreground align-middle border-r last:border-r-0",
        className
      )}
      {...props}
    />
  )
}

function TableCell({ className, ...props }: React.ComponentProps<"td">) {
  return (
    <td
      className={cn(
        "px-3 py-2 align-middle border-r last:border-r-0 text-sm text-muted-foreground whitespace-nowrap",
        className
      )}
      {...props}
    />
  )
}

function TableCaption({
  className,
  ...props
}: React.ComponentProps<"caption">) {
  return (
    <caption
      className={cn("text-muted-foreground mt-4 text-sm", className)}
      {...props}
    />
  )
}

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
}
