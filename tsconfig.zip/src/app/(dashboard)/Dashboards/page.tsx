const Dashboards = () => {
    return (
        <div className="w-full h-full flex items-center justify-center">
            <p className="text-4xl">Dashboard Page</p>
        </div>
    )
}

export default Dashboards;